import * as functions from "firebase-functions";
import { Resend } from "resend";
import cors from "cors";

const corsHandler = cors({ origin: true });

// Firebase HTTP Function
export const sendConfirmationEmail = functions.https.onRequest(
  async (req, res) => {
    corsHandler(req, res, async () => {
      // 1. Get API key from Firebase config
      const apiKey = process.env.RESEND_EMAILS_API_KEY;
      
      // 2. Validate API key
      if (!apiKey) {
        functions.logger.error("RESEND_API_KEY is not configured");
        return res.status(500).json({
          error: "Server configuration error - API key missing"
        });
      }

      const resend = new Resend(apiKey);
      
      // 3. Validate request method
      if (req.method !== "POST") {
        return res.status(400).send("Invalid method. Only POST allowed");
      }

      // 4. Extract data from request body
      const { email, code } = req.body;
      if (!email || !code) {
        return res.status(400).json({
          error: "Missing required parameters: email and code"
        });
      }

      try {
        // 5. Generate email HTML
        const emailHtml = generateEmailHtml(code);

        // 6. Send email via Resend
        await resend.emails.send({
          from: 'Alertnet <onboarding@resend.dev>', 
          to: ['mpilonhleradebe@icloud.com'],
          subject: 'Welcome to Alertnet - Confirm Your Account',
          html: emailHtml,
        });

        // 7. Return success response
        return res.status(200).json({
          message: "Confirmation email sent successfully"
        });
      } catch (error) {
        functions.logger.error("Email sending failed:", error);
        return res.status(500).json({
          error: "Failed to send confirmation email",
          details: error instanceof Error ? error.message : String(error)
        });
      }
    });
  }
);

// Helper function to generate email HTML
function generateEmailHtml(confirmationCode) {
  return `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" lang="en">
<head>
<title>Confirm Your Account</title>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<!--[if !mso]><!-->
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!--<![endif]-->
<meta name="x-apple-disable-message-reformatting" content="" />
<meta content="target-densitydpi=device-dpi" name="viewport" />
<meta content="true" name="HandheldFriendly" />
<meta content="width=device-width" name="viewport" />
<meta name="format-detection" content="telephone=no, date=no, address=no, email=no, url=no" />
<style type="text/css">
table {
border-collapse: separate;
table-layout: fixed;
mso-table-lspace: 0pt;
mso-table-rspace: 0pt
}
table td {
border-collapse: collapse
}
.ExternalClass {
width: 100%
}
.ExternalClass,
.ExternalClass p,
.ExternalClass span,
.ExternalClass font,
.ExternalClass td,
.ExternalClass div {
line-height: 100%
}
body, a, li, p, h1, h2, h3 {
-ms-text-size-adjust: 100%;
-webkit-text-size-adjust: 100%;
}
html {
-webkit-text-size-adjust: none !important
}
body {
min-width: 100%;
Margin: 0px;
padding: 0px;
}
body, #innerTable {
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale
}
#innerTable img+div {
display: none;
display: none !important
}
img {
Margin: 0;
padding: 0;
-ms-interpolation-mode: bicubic
}
h1, h2, h3, p, a {
line-height: inherit;
overflow-wrap: normal;
white-space: normal;
word-break: break-word
}
a {
text-decoration: none
}
h1, h2, h3, p {
min-width: 100%!important;
width: 100%!important;
max-width: 100%!important;
display: inline-block!important;
border: 0;
padding: 0;
margin: 0
}
a[x-apple-data-detectors] {
color: inherit !important;
text-decoration: none !important;
font-size: inherit !important;
font-family: inherit !important;
font-weight: inherit !important;
line-height: inherit !important
}
u + #body a {
color: inherit;
text-decoration: none;
font-size: inherit;
font-family: inherit;
font-weight: inherit;
line-height: inherit;
}
a[href^="mailto"],
a[href^="tel"],
a[href^="sms"] {
color: inherit;
text-decoration: none
}
</style>
<style type="text/css">
@media (min-width: 481px) {
.hd { display: none!important }
}
</style>
<style type="text/css">
@media (max-width: 480px) {
.hm { display: none!important }
}
</style>
<style type="text/css">
@media (max-width: 480px) {
.t41,.t46{mso-line-height-alt:0px!important;line-height:0!important;display:none!important}.t42{padding:40px!important;border-radius:0!important}.t32{text-align:left!important}.t25{display:revert!important}.t27,.t31{vertical-align:top!important;width:auto!important;max-width:100%!important}
}
</style>
</head>
<body id="body" class="t49" style="min-width:100%;Margin:0px;padding:0px;background-color:#FFFFFF;">
  <!-- Email body structure -->
  <div class="t48" style="background-color:#FFFFFF;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
      <tr>
        <td class="t47" style="font-size:0;line-height:0;mso-line-height-rule:exactly;background-color:#FFFFFF;" valign="top" align="center">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" align="center" id="innerTable">
            <tr>
              <td>
                <div class="t41" style="mso-line-height-rule:exactly;mso-line-height-alt:50px;line-height:50px;font-size:1px;display:block;">&nbsp;</div>
              </td>
            </tr>
            <tr>
              <td align="center">
                <table class="t45" role="presentation" cellpadding="0" cellspacing="0" style="Margin-left:auto;Margin-right:auto;">
                  <tr>
                    <td width="600" class="t44" style="width:600px;">
                      <table class="t43" role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;">
                        <tr>
                          <td class="t42" style="border:1px solid #EBEBEB;overflow:hidden;background-color:#FFFFFF;padding:44px 42px 32px 42px;border-radius:3px 3px 3px 3px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100% !important;">
                              <tr>
                                <td align="left">
                                  <table class="t4" role="presentation" cellpadding="0" cellspacing="0" style="Margin-right:auto;">
                                    <tr>
                                      <td width="70" class="t3" style="width:70px;">
                                        <table class="t2" role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;">
                                          <tr>
                                            <td class="t1"><div style="font-size:0px;"><img class="t0" style="display:block;border:0;height:auto;width:100%;Margin:0;max-width:100%;" width="70" height="70" alt="Alertnet Logo" src="https://06dcd0c3-8f81-42e8-a5ae-4fa1923dd89b.b-cdn.net/e/7efe5763-b5ac-4d3e-8137-ee73cde8d3ee/ba223ca6-120a-4097-8fbe-f5d615813890.png"/></div></td>
                                          </tr>
                                        </table>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td><div class="t5" style="mso-line-height-rule:exactly;mso-line-height-alt:42px;line-height:42px;font-size:1px;display:block;">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="center">
                                  <table class="t10" role="presentation" cellpadding="0" cellspacing="0" style="Margin-left:auto;Margin-right:auto;">
                                    <tr>
                                      <td width="514" class="t9" style="width:600px;">
                                        <table class="t8" role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;">
                                          <tr>
                                            <td class="t7" style="border-bottom:1px solid #EFF1F4;padding:0 0 18px 0;"><h1 class="t6" style="margin:0;Margin:0;font-family:Montserrat,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;line-height:28px;font-weight:700;font-style:normal;font-size:24px;text-decoration:none;text-transform:none;letter-spacing:-1px;direction:ltr;color:#141414;text-align:left;mso-line-height-rule:exactly;mso-text-raise:1px;">Confirm your account</h1></td>
                                          </tr>
                                        </table>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td><div class="t11" style="mso-line-height-rule:exactly;mso-line-height-alt:18px;line-height:18px;font-size:1px;display:block;">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="center">
                                  <table class="t16" role="presentation" cellpadding="0" cellspacing="0" style="Margin-left:auto;Margin-right:auto;">
                                    <tr>
                                      <td width="514" class="t15" style="width:600px;">
                                        <table class="t14" role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;">
                                          <tr>
                                            <td class="t13"><p class="t12" style="margin:0;Margin:0;font-family:Open Sans,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;line-height:25px;font-weight:400;font-style:normal;font-size:15px;text-decoration:none;text-transform:none;letter-spacing:-0.1px;direction:ltr;color:#141414;text-align:left;mso-line-height-rule:exactly;mso-text-raise:3px;">Please enter this code on the sign-up page to continue</p></td>
                                          </tr>
                                        </table>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td><div class="t18" style="mso-line-height-rule:exactly;mso-line-height-alt:24px;line-height:24px;font-size:1px;display:block;">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="left">
                                  <table class="t22" role="presentation" cellpadding="0" cellspacing="0" style="Margin-right:auto;">
                                    <tr>
                                      <td width="144" class="t21" style="width:144px;">
                                        <table class="t20" role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;">
                                          <tr>
                                            <td class="t19" style="overflow:hidden;background-color:#FE5235;text-align:center;line-height:34px;mso-line-height-rule:exactly;mso-text-raise:5px;padding:0 23px 0 23px;border-radius:40px 40px 40px 40px;"><span class="t17" style="display:block;margin:0;Margin:0;font-family:Sofia Sans,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;line-height:34px;font-weight:700;font-style:normal;font-size:16px;text-decoration:none;text-transform:none;letter-spacing:-0.2px;direction:ltr;color:#FFFFFF;text-align:center;mso-line-height-rule:exactly;mso-text-raise:5px;">${confirmationCode}</span></td>
                                          </tr>
                                        </table>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                              <tr>
                                <td><div class="t36" style="mso-line-height-rule:exactly;mso-line-height-alt:40px;line-height:40px;font-size:1px;display:block;">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="center">
                                  <table class="t40" role="presentation" cellpadding="0" cellspacing="0" style="Margin-left:auto;Margin-right:auto;">
                                    <tr>
                                      <td width="514" class="t39" style="width:600px;">
                                        <table class="t38" role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;">
                                          <tr>
                                            <td class="t37" style="border-top:1px solid #DFE1E4;padding:24px 0 0 0;">
                                              <div class="t35" style="width:100%;text-align:left;">
                                                <div class="t34" style="display:inline-block;">
                                                  <table class="t33" role="presentation" cellpadding="0" cellspacing="0" align="left" valign="top">
                                                    <tr class="t32">
                                                      <td></td>
                                                      <td class="t27" valign="top">
                                                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="t26" style="width:auto;">
                                                          <tr>
                                                            <td class="t24" style="background-color:#FFFFFF;text-align:center;line-height:20px;mso-line-height-rule:exactly;mso-text-raise:2px;"><span class="t23" style="display:block;margin:0;Margin:0;font-family:Open Sans,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;line-height:20px;font-weight:600;font-style:normal;font-size:14px;text-decoration:none;direction:ltr;color:#222222;text-align:center;mso-line-height-rule:exactly;mso-text-raise:2px;">Alertnet</span></td>
                                                            <td class="t25" style="width:20px;" width="20"></td>
                                                          </tr>
                                                        </table>
                                                      </td>
                                                      <td class="t31" valign="top">
                                                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="t30" style="width:auto;">
                                                          <tr>
                                                            <td class="t29" style="background-color:#FFFFFF;text-align:center;line-height:20px;mso-line-height-rule:exactly;mso-text-raise:2px;"><span class="t28" style="display:block;margin:0;Margin:0;font-family:Open Sans,BlinkMacSystemFont,Segoe UI,Helvetica Neue,Arial,sans-serif;line-height:20px;font-weight:500;font-style:normal;font-size:14px;text-decoration:none;direction:ltr;color:#B4BECC;text-align:center;mso-line-height-rule:exactly;mso-text-raise:2px;">Now you can be safe.</span></td>
                                                          </tr>
                                                        </table>
                                                      </td>
                                                      <td></td>
                                                    </tr>
                                                  </table>
                                                </div>
                                              </div>
                                            </td>
                                          </tr>
                                        </table>
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td><div class="t46" style="mso-line-height-rule:exactly;mso-line-height-alt:50px;line-height:50px;font-size:1px;display:block;">&nbsp;</div></td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </div>
  <div class="gmail-fix" style="display: none; white-space: nowrap; font: 15px courier; line-height: 0;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>
</body>
</html>`;
}

