import { StyleSheet, View, Dimensions, BackHandler } from 'react-native';
import React, { useState, useEffect } from 'react';
import Map from '../componets/Map';
import TopBar from '../componets/TopBar';
import BottomNav from '../componets/BottomNav';
import { MapProvider } from '../contexts/MapContext';
import { LanguageProvider } from './SafetyResource_Screens/LanguagePage'; // Import the LanguageProvider
import MyProfile from '../screens/MyProfile';

import WalkPartner from './WalkPartner';
import SOSPage from './SOS';
import QrCode from './QrCode';
import SafetyResources from '../screens/SafetyResource_Screens/SafetyResources';
import TestSOS from './SafetyResource_Screens/TestSOS';
import LiveLocation from './SafetyResource_Screens/LiveLocation';
import VoiceTrigger from './SafetyResource_Screens/VoiceTrigger';
import Unsafe from './SafetyResource_Screens/Unsafe';
import PreviousWalks from './SafetyResource_Screens/previousWalks';
import EmergencyContacts from './SafetyResource_Screens/emergencyContacts';
import LanguagePage from './SafetyResource_Screens/LanguagePage';
import SafetyVideos from './SafetyResource_Screens/safetyVideos';
import OfflineMap from './SafetyResource_Screens/offlineMap';
import WalkingAloneTips from './SafetyResource_Screens/walkingAlone';
import Subscription from './SafetyResource_Screens/Subscription';
import SafetyZones from './SafetyResource_Screens/safetyZones';

const { width, height } = Dimensions.get('window');

// Main Home Component (now wrapped with LanguageProvider)
const Home = ({handleLogout}) => {
  return (
    <LanguageProvider>
      <HomeContent handleLogout={handleLogout} />
    </LanguageProvider>
  );
};

// Separated the main logic into HomeContent component
const HomeContent = ({handleLogout}) => {
  const [isNotHome, setIsNotHome] = useState(false);
  const [isSOS, setIsSOS] = useState(false);
  const [isWalkPartner, setIsWalkPartner] = useState(false);
  const [isQrCode, setIsQrCode] = useState(false);
  const [isPeopleActive, setIsPeopleActive] = useState(false);
  const [isTopBarManuallyExpanded, setIsTopBarManuallyExpanded] = useState(false);
  const [isSafetyResources, setIsSafetyResources] = useState(false);
  const [isTestSOS, setIsTestSOS] = useState(false);
  const [isLiveLocation, setIsLiveLocation] = useState(false);
  const [isVoiceTrigger, setIsVoiceTrigger] = useState(false);
  const [isUnsafePage, setIsUnsafePage] = useState(false);
  const [isUserProfile, setIsUserProfile] = useState(false);
  const [isPreviousWalks, setIsPreviousWalks] = useState(false);
  const [isEmergencyContacts, setIsEmergencyContacts] = useState(false);
  const [isLanguagePage, setIsLanguagePage] = useState(false);
  const [isSafetyVideos, setIsSafetyVideos] = useState(false);
  const [isOfflineMap, setIsOfflineMap] = useState(false);
  const [isSubscriptionScreen, setIsSubscriptionScreen] = useState(false);
  const [isWalkingAloneTips, setIsWalkingAloneTips] = useState(false);
  const [isSubscription, setIsSubscription] = useState(false);
  const [isSafetyZones, setIsSafetyZones] = useState(false);
  const [previousScreen, setPreviousScreen] = useState('home');

  // Hardware back button handler
  useEffect(() => {
    const handleBackPress = () => {
      if (isWalkPartner) { setIsWalkPartner(false); return true; }
      if (isUserProfile) { setIsUserProfile(false); return true; }
      if (isQrCode) { setIsQrCode(false); setIsSOS(true); return true; }
      if (isTestSOS) { setIsTestSOS(false); setIsSafetyResources(true); return true; }
      if (isLiveLocation) { setIsLiveLocation(false); setIsSafetyResources(true); return true; }
      if (isVoiceTrigger) { setIsVoiceTrigger(false); setIsSafetyResources(true); return true; }
      if (isUnsafePage) { setIsUnsafePage(false); setIsSafetyResources(true); return true; }
      if (isPreviousWalks) { setIsPreviousWalks(false); setIsSafetyResources(true); return true; }
      if (isEmergencyContacts) { setIsEmergencyContacts(false); setIsSafetyResources(true); return true; }
      if (isLanguagePage) { setIsLanguagePage(false); setIsSafetyResources(true); return true; }
      if (isSafetyVideos) { setIsSafetyVideos(false); setIsSafetyResources(true); return true; }
      if (isOfflineMap) { setIsOfflineMap(false); setIsSafetyResources(true); return true; }
      if (isSubscriptionScreen) { setIsSubscriptionScreen(false); setIsSafetyResources(true); return true; }
      if (isWalkingAloneTips) { setIsWalkingAloneTips(false); setIsSafetyResources(true); return true; }
      if (isSafetyZones) { setIsSafetyZones(false); setIsSafetyResources(true); return true; }
      if (isSafetyResources) {
        setIsSafetyResources(false);
        if (previousScreen === 'sos') setIsSOS(true);
        return true;
      }
      if (isSOS) { setIsSOS(false); return true; }
      return false; // Allow default back behavior (exit app)
    };

    const backHandler = BackHandler.addEventListener('hardwareBackPress', handleBackPress);
    return () => backHandler.remove();
  }, [isWalkPartner, isUserProfile, isSOS, isQrCode, isSafetyResources, isTestSOS, isLiveLocation, isVoiceTrigger, isUnsafePage, isPreviousWalks, isEmergencyContacts, isLanguagePage, isSafetyVideos, isOfflineMap, isSubscriptionScreen, isWalkingAloneTips, isSafetyZones, previousScreen]);

  if (isWalkPartner) {
    return <WalkPartner setIsWalkPartner={setIsWalkPartner} />;
  }

  if (isUserProfile) {
    return <MyProfile setIsUserProfile={setIsUserProfile} />;
  }

  if (isSOS) {
    return (
      <SOSPage
        setIsSOS={setIsSOS}
        setIsQrCode={setIsQrCode}
        setIsSafetyResources={() => { setPreviousScreen('sos'); setIsSafetyResources(true); }}
      />
    );
  }

  if (isQrCode) {
    return <QrCode setIsQrCode={setIsQrCode} setIsSOS={setIsSOS} />;
  }

  if (isTestSOS) {
    return (
      <TestSOS
        setIsTestSOS={setIsTestSOS}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isLiveLocation) {
    return (
      <LiveLocation
        setIsLiveLocation={setIsLiveLocation}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isVoiceTrigger) {
    return (
      <VoiceTrigger
        setIsVoiceTrigger={setIsVoiceTrigger}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isSafetyResources) {
    console.log("Home: isSafetyResources is true, previousScreen:", previousScreen);
    let backgroundContent = null;
    
    if (previousScreen === 'sos') {
      backgroundContent = (
        <SOSPage
          setIsSOS={setIsSOS}
          setIsQrCode={setIsQrCode}
          setIsSafetyResources={() => { setPreviousScreen('sos'); setIsSafetyResources(true); }}
        />
      );
    } else if (previousScreen === 'home') {
      backgroundContent = (
        <MapProvider>
          <View style={styles.container}>
            <Map />
            <TopBar 
              isNotHome={isNotHome} 
              isPeopleActive={isPeopleActive} 
              isTopBarManuallyExpanded={isTopBarManuallyExpanded}
              setIsTopBarManuallyExpanded={setIsTopBarManuallyExpanded}
              setIsUserProfile={setIsUserProfile} 
              setIsSafetyResources={() => { setPreviousScreen('home'); setIsSafetyResources(true); }} 
            />
            <BottomNav
              isNotHome={isNotHome}
              setIsNotHome={setIsNotHome}
              isWalkPartner={isWalkPartner}
              setIsWalkPartner={setIsWalkPartner}
              setIsSOS={setIsSOS}
              setIsPeopleActive={setIsPeopleActive}
              setIsTopBarManuallyExpanded={setIsTopBarManuallyExpanded}
            />
          </View>
        </MapProvider>
      );
    }

    return (
      <SafetyResources
        setIsSafetyResources={setIsSafetyResources}
        setIsSOS={setIsSOS}
        setIsTestSOS={setIsTestSOS}
        setIsLiveLocation={setIsLiveLocation}
        setIsVoiceTrigger={setIsVoiceTrigger}
        setIsUnsafePage={setIsUnsafePage}
        setIsPreviousWalks={setIsPreviousWalks} 
        setIsEmergencyContacts = {setIsEmergencyContacts}
        setIsLanguagePage = {setIsLanguagePage}
        setIsSafetyVideos = {setIsSafetyVideos}
        setIsOfflineMap = {setIsOfflineMap}
        setIsSubscription = {setIsSubscription} 
        setIsWalkingAloneTips={setIsWalkingAloneTips}
        handleLogout={handleLogout}
        setIsSubscriptionScreen = {setIsSubscriptionScreen}
        setIsSafetyZones={setIsSafetyZones}
        previousScreen={previousScreen}
        backgroundContent={backgroundContent}
      />
    );
  }

  if (isUnsafePage) {
    return (
      <Unsafe
        setIsUnsafePage={setIsUnsafePage}
        setIsSafetyResources={setIsSafetyResources}
        setIsSOS={setIsSOS}
      />
    );
  }

  if (isPreviousWalks) {
    return (
      <PreviousWalks
        setIsPreviousWalks={setIsPreviousWalks}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isEmergencyContacts) {
    return (
      <EmergencyContacts
        setIsEmergencyContacts={setIsEmergencyContacts}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isLanguagePage) {
    return (
      <LanguagePage
        setIsLanguagePage={setIsLanguagePage}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isSafetyVideos) {
    return (
      <SafetyVideos
        setIsSafetyVideos={setIsSafetyVideos}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isOfflineMap) {
    return (
      <OfflineMap
        setIsOfflineMap={setIsOfflineMap}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isSubscriptionScreen) {
    return (
      <Subscription
        setIsSubscriptionScreen={setIsSubscriptionScreen}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }

  if (isWalkingAloneTips) {
    return (
      <WalkingAloneTips
        setIsWalkingAloneTips={setIsWalkingAloneTips}
        setIsSafetyResources={setIsSafetyResources}
      />
    );
  }



  return (
    <MapProvider>
      <View style={styles.container}>
        <Map />
        <TopBar 
          isNotHome={isNotHome} 
          isPeopleActive={isPeopleActive} 
          isTopBarManuallyExpanded={isTopBarManuallyExpanded}
          setIsTopBarManuallyExpanded={setIsTopBarManuallyExpanded}
          setIsUserProfile={setIsUserProfile} 
          setIsSafetyResources={() => { setPreviousScreen('home'); setIsSafetyResources(true); }} 
        />
        <BottomNav
          isNotHome={isNotHome}
          setIsNotHome={setIsNotHome}
          isWalkPartner={isWalkPartner}
          setIsWalkPartner={setIsWalkPartner}
          setIsSOS={setIsSOS}
          setIsPeopleActive={setIsPeopleActive}
          setIsTopBarManuallyExpanded={setIsTopBarManuallyExpanded}
        />
        
        {/* SafetyZones Popup */}
        {isSafetyZones && (
          <SafetyZones
            setIsSafetyZones={setIsSafetyZones}
            setIsSafetyResources={setIsSafetyResources}
          />
        )}
      </View>
    </MapProvider>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    // flex: 1,
  },
});